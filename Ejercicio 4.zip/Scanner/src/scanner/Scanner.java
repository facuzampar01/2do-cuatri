/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package scanner;

import java.util.Scanner;

/**
 *
 * @author ZAMPAR
 */
public class Scanner {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int edad;
        String nombre;
        
        System.out.println("Ingrese su nombre");
        nombre = input.nextLine();
        
        System.out.println("Ingrese su edad");
        edad = input.nextInt();
        
        System.out.println("El nombre ingresado es "+ nombre + " y la edad es " + edad);
    }
    
}
