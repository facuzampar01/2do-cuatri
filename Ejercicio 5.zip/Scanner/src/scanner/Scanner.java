/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package scanner;

import java.util.Scanner;

/**
 *
 * @author ZAMPAR
 */
public class Scanner {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num1, num2, suma, resta, multi;
        double division;
        
        System.out.println("Ingrese el primer numero");
        num1 = Integer.parseInt(input.nextLine());
        
        System.out.println("Ingrese el segundo numero");
        num2 = Integer.parseInt(input.nextLine());
        
        suma = num1 + num2;
        resta = num1 - num2;
        multi = num1 * num2;
        division = num1 / num2;
        
        System.out.println("Suma: " + suma + "\nResta: " + resta + "\nMultiplicacion: " + multi + "\nDivision: " + division);
    }
    
}
