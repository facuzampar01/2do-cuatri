/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package holamundo;
/**
 *
 * @author ZAMPAR
 */
public class HolaMundo {

    public static void main(String[] args) {
        String nombre = "Facundo";
        int edad = 18;
        double altura = 1.70;
        boolean estudiante = true;
        
        
        System.out.println("Hola, soy "+ nombre + ", tengo "+ edad + " años de edad y mido " + altura + "m. Soy estudiante: " + estudiante);
    }
    
}
